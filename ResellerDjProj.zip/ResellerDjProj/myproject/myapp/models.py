from django.db import models
from django.core.exceptions import ValidationError


# Create your models here.
class User(models.Model):
    name=models.CharField(max_length=30)
    contact=models.CharField(max_length=15)
    email=models.EmailField(max_length=50)
    password=models.CharField(max_length=30)
    rePassword=models.CharField(max_length=30)
    #verification=models.BooleanField("I have given every details correctly",default=False)

    def __int__(self):
        return self.id


    


class CompanyDetails(models.Model):
    Uid=models.ForeignKey(User, on_delete=models.CASCADE)
    companyname=models.CharField(max_length=30)
    websiteAddress=models.CharField(max_length=30)
    mobilenumber=models.CharField(max_length=15)
    aadharCardNo=models.CharField(max_length=15)
    dateOfBirth=models.DateField(max_length=15,null=True,blank=True)
    companyAddress=models.TextField(max_length=20)
    state=models.CharField(max_length=15)
    country=models.CharField(max_length=15)

    def __int__(self):
        return self.Uid

class ClientDetails(models.Model):
    cname=models.CharField(max_length=50)
    webAddress=models.CharField(max_length=50)
    uid=models.ForeignKey(User, on_delete=models.CASCADE)
    email=models.EmailField(max_length=50)
    #slug=models.SlugField(unique=True)

    '''def __str__(self):
        return self.cname
    
    def __str__(self):
        return self.webAddress

    def __str__(self):
        return self.email

    def __int__(self):
        return self.uid'''

    def __int__(self):
        return self.id

class ClientSignUp(models.Model):
    name=models.CharField(max_length=30)
    contact=models.CharField(max_length=15)
    email=models.EmailField(max_length=50)
    password=models.CharField(max_length=30)
    rePassword=models.CharField(max_length=30)
    UserId=models.ForeignKey(User, on_delete=models.CASCADE)

    def __int__(self):
        return self.id