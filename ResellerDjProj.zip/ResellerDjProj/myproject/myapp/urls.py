from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.HomePage),
    path("HomePage",views.HomePage),
    path("loginPage",views.LoginPage),
    path("login",views.Login),
    path("signUppage",views.SignUpPage),
    path("user",views.signUp),
    path("logoutpage",views.LogoutPage,name="logoutpage"),
    path("Company",views.CompanyPage,name="Company"),
    path("companydetails",views.Company),
    #path("userlist",views.UserList),
    path('client/<slug:myslug>', views.ClientPage,name="client"),
    #path('clients/<slug:myslug>',views.Client,name="clientsave"),
    path('home2/<slug:the_slug>',views.HomePage2,name="home2"),
    path('clientsignupPage/<slug:myslug2>',views.ClientSignupPage, name='clientsignupPage'),
    path('home3/<slug:myslug1>',views.HomePage3,name="home3"),
    #path('clientsign',views.ClientSignUp),

]
