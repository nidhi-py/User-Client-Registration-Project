from django import forms
from myapp.models import User, CompanyDetails, ClientDetails, ClientSignUp
from django.core import validators
from django.forms import ValidationError
from django.http import HttpResponse
from django.core.validators import MinLengthValidator

class UserForm(forms.ModelForm):
    class Meta:
        model= User
        fields='__all__'
        # widgets = {'Uid': forms.HiddenInput()}
    '''username = forms.CharField(widget=forms.TextInput(
        attrs={'class':'form-control','placeholder':'Enter Username'}
    ),required=True,max_length=50)
    contact = forms.CharField(widget=forms.TextInput(
        attrs={'class':'form-control','placeholder':'Enter Contact'}
    ),required=True,max_length=50)
    
    password = forms.CharField(widget=forms.PasswordInput(
        attrs={'class':'form-control','placeholder':'Enter Password'}
    ),required=True,max_length=50)
    confirm_password = forms.CharField(widget=forms.PasswordInput(
        attrs={'class':'form-control','placeholder':'Confirm password'}
    ),required=True,max_length=50)
    class Meta():
        model= User
        fields='username','contact','email','password','confirm_password'
    def clean(self):
        cleaned_data = super(UserForm, self).clean()
        # print(cleaned_data)
        print("1111111111111111111111111111111")
        #print(cleaned_data)
        password =  cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password and confirm_password:
            if password != confirm_password:
                print("2222222222222222")
                raise forms.ValidationError(
                    "password and confirm_password does not match"
                )   
                
                raise forms.ValidationError("The two password fields must match.")
    
        return confirm_password '''
        

class CompanyDetailsForm(forms.ModelForm):
    class Meta:
        model= CompanyDetails
        fields='companyname','websiteAddress','mobilenumber','aadharCardNo','dateOfBirth','companyAddress','state','country'
        # widgets = {'Uid': forms.HiddenInput()}

class ClientForm(forms.ModelForm):
    class Meta:
        model= ClientDetails
        fields='cname','webAddress','email'

class ClientSignUpForm(forms.ModelForm):
    class Meta:
        model= ClientSignUp
        fields='name','contact','email','password','rePassword'