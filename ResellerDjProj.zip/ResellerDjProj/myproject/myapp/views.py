from django.shortcuts import render, redirect
from django.http import HttpResponse
from myapp.models import User, CompanyDetails, ClientDetails, ClientSignUp
from myapp.form import UserForm, CompanyDetailsForm, ClientForm, ClientSignUpForm
from django.conf import settings
from django.forms import ValidationError
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.core import mail
# Create your views here.

def HomePage(request):
    return render(request,'home.html')

def SignUpPage(request):
    u=UserForm()
    return render(request,"signup.html",{'form':u})

def signUp(request):
    # u=UserForm(request.POST)
    u = UserForm(request.POST or None)
    if request.method == "POST" and u.is_valid():    
        print("00000000000000000000000000")
        print(u.cleaned_data)
        data=u.cleaned_data
        u.save()
        '''email=u.cleaned_data.get("email")
        send_mail(
        'Subject',
        '<a href="http://127.0.0.1:8000/loginPage">Visit W3Schools.com!</a>',
        settings.EMAIL_HOST_USER,
        [email],
        fail_silently=False,
        '''
        return redirect('/HomePage')

    # elif u.data['password'] != u.data['confirm_password']:
    #     u.add_error('confirm_password', 'The passwords do not match')

    return redirect('/signUppage',locals())

#def UserList(request):
    
def CompanyPage(request):
    c=CompanyDetailsForm()
    return render(request, 'company.html',{'cd':c})

def Company(request):
    
    print(request.POST)
    c=CompanyDetailsForm(request.POST)
    Uid=request.session.get('username')
    user=User.objects.get(id=Uid)
    a=CompanyDetails()
    # a.Uid=user
    # a.save()
    # c.Uid = Uid
    # c.save()
    a = c.save(commit=False)
    a.Uid = user
    a.save()    
    return render(request,'home.html')

'''def CompanyPage(request):
    c=CompanyDetailsForm
    return render(request, 'company.html',{'cd':c})

def Company(request):
    c=CompanyDetailsForm(request.POST)
    c.save()
    return render(request,'home.html')'''

def LoginPage(request):
    return render(request,'login.html')

def Login(request):
    em=request.POST.get('email')
    passwd=request.POST.get('password')
    #print(email,'  ',password)
    if em=="helloworld" and passwd=="hello12":
        request.session['admin']=em
        return redirect('/HomePage')
    else:
        # try:
        u=User.objects.get(email=em)
        print(u.id)
        if em==u.email and passwd==u.password:
            request.session['username']=u.id
            return redirect("/HomePage")
        else:
            return HttpResponse("Template not found")
        # except:
            # return render(request,'login.html')#{'msg':""}

def LogoutPage(request):
    ls=list(request.session.keys())
    for i in ls:
        del request.session[i]
    return redirect('/HomePage')

def ClientPage(request,myslug):
    cl=ClientForm()
    print("!11111111111")
    
    if request.method == "POST":
        print("POSTTTTT")
        print(request.POST)  
        c2=ClientForm(request.POST)
        c=ClientDetails()
        u=User.objects.get(id=myslug)
        c=c2.save(commit=False)
        c.uid = u
        c.save()
        email=c2.cleaned_data.get("email")
        client_id=myslug
        subject = 'Invite'
        html_message = render_to_string("clientactivation.html",locals())
        plain_message = strip_tags(html_message)
        from_email = 'From nidhipatankar98@gmail.com'
        to = email

        mail.send_mail(subject, plain_message, from_email, [to], html_message=html_message)   
        '''email=c2.cleaned_data.get("email")
        send_mail(
        'Subject',
        '<a href="http://127.0.0.1:8000/clientsignupPage">Visit W3Schools.com!</a>',
        settings.EMAIL_HOST_USER,
        [email],
        fail_silently=False,
        )'''
    return render(request, 'clients.html',{'cl':cl})

'''def Client(request,myslug):
    print("!1111111111122222222")
    print(request.POST)
    cl=ClientForm(request.POST)
    my_slug=request.GET.get('myslug')
    c=ClientDetails()
    c.slug=my_slug
    #u=User.objects.get(id=my_slug)
    #c=ClientDetails()
    c=cl.save(commit=False)
    #c.uid=u                                           #if cl.is_valid:
    c.save()
    return render(request,'home2.html')
    email=cl.cleaned_data.get("email")
        send_mail(
        'Subject',
        '<a href="http://127.0.0.1:8000/clientsignupPage">Visit W3Schools.com!</a>',
        settings.EMAIL_HOST_USER,
        [email],
        fail_silently=False,
        )'''
   

def HomePage2(request,the_slug):
    myslug = the_slug
    return render(request,'home2.html',locals())

def HomePage3(request,myslug1):
    myslug2=myslug1
    return render(request, 'home3.html',locals())

def ClientSignupPage(request,myslug2):
    a=ClientSignUpForm
    if request.method == "POST":
        a=ClientSignUpForm(request.POST)
        s=ClientSignUp()
        c=User.objects.get(id=myslug2)
        s=a.save(commit=False)
        s.UserId=c
        s.save()
    return render(request,"dashboard.html",{'a':a})

'''def ClientSignUp(request):
    a=ClientSignUpForm(request.POST)
    a.save()
    return render(request,'dashboard.html')'''

