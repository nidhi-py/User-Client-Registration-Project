from django.contrib import admin
from .models import User, CompanyDetails, ClientDetails
from django.contrib.auth.models import Group
from django.urls import path
from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.core import mail
# Register your models here.

admin.site.site_header="My django website"

class UserAdmin(admin.ModelAdmin):
    fields= ("name", "contact", "email","id")
    list_display=('name', 'contact','email',"id")

    actions= ['Shortlist']

   
        

    def Shortlist(self, request, queryset):
        print(queryset,"1111")
        for profile in queryset:
            user_id = profile.id

            subject = 'Invite'
            html_message = render_to_string("activation.html",locals())
            plain_message = strip_tags(html_message)
            from_email = 'From nidhipatankar98@gmail.com'
            to = profile.email

            mail.send_mail(subject, plain_message, from_email, [to], html_message=html_message)            
            # send_mail(subject="Invite", message=message, from_email='nidhipatankar98@gmail.com', recipient_list=[profile.email]) # use your email function here
            #send_invite.short_description = "Send invitation"
        
        
        '''send_mail(
            'Hello',
            'Congratulations',
            settings.EMAIL_HOST_USER,
            [self.email],
            fail_silently=false,
        )
        
        
        for profile in queryset:
            send_mail(subject="Invite", message="Hello", from_email='nidhipatankar98@gmail.com', recipient_list=[profile.email]) # use your email function here
            send_invite.short_description = "Send invitation"'''

class ClientDetailsAdmin(admin.ModelAdmin):
    fields= ("cname", "webAddress", "uid", "email")
    list_display=('cname', 'webAddress', 'uid', 'email')



admin.site.register(User, UserAdmin)
admin.site.register(CompanyDetails)
admin.site.register(ClientDetails,ClientDetailsAdmin)